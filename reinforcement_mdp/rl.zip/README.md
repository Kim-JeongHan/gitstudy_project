# project-6-rl
Trimmed down reinforcement project, and added Deep Q learning Pacman
